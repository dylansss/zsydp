<template>
  <div class="container">

    <router-view></router-view>
  </div>
</template>


<style lang="scss" scoped>
.container{

width: 100%;
height: 100%;
overflow: hidden;
background: url(../public/img/bg.png)  no-repeat;
background-size: 100% 100%;
}
</style>