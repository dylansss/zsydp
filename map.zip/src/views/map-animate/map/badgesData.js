export default [
  {
    adcode: 150000,
    value: 7621,
    geometry: { type: "Point", coordinates: [111.670801, 40.818311] },
  },
  {
    adcode: 140000,
    value: 8787,
    geometry: { type: "Point", coordinates: [112.549248, 37.857014] },
  },
  {
    adcode: 320000,
    value: 9821,
    geometry: { type: "Point", coordinates: [118.767413, 32.041544] },
  },
  {
    adcode: 500000,
    value: 8765,
    geometry: { type: "Point", coordinates: [106.504962, 29.533155] },
  },
  {
    adcode: 530000,
    value: 8741,
    geometry: { type: "Point", coordinates: [102.712251, 25.040609] },
  },
];
